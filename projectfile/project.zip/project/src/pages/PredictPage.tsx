import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, Camera, AlertCircle, Loader2 } from 'lucide-react';

interface PredictPageProps {
  setPredictionResult: (result: any) => void;
  setUploadedImage: (image: string) => void;
}

const PredictPage: React.FC<PredictPageProps> = ({ setPredictionResult, setUploadedImage }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const navigate = useNavigate();

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = e.dataTransfer.files;
    if (files && files[0]) {
      handleFileSelect(files[0]);
    }
  }, []);

  const handleFileSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      handleFileSelect(files[0]);
    }
  };

  const handleSubmit = async () => {
    if (!selectedFile) {
      alert('Please select an image first');
      return;
    }

    setIsUploading(true);

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);

      // Simulate API call - in real implementation, this would call your Flask backend
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Mock prediction result - replace with actual API call
      const mockResult = {
        predicted_class: 'Basmati',
        confidence: 0.89,
        all_predictions: {
          'Basmati': 0.89,
          'Jasmine': 0.08,
          'Arborio': 0.02,
          'Brown Rice': 0.01,
          'Wild Rice': 0.00
        }
      };

      setPredictionResult(mockResult);
      if (previewUrl) {
        setUploadedImage(previewUrl);
      }
      navigate('/results');

    } catch (error) {
      console.error('Error during prediction:', error);
      alert('Error occurred during prediction. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="flex-1 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Rice Variety Classification
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Upload an image of rice grains to get instant AI-powered identification 
            with detailed classification results.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="p-8">
            {/* Upload Area */}
            <div
              className={`relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 ${
                dragActive
                  ? 'border-amber-400 bg-amber-50'
                  : 'border-gray-300 hover:border-amber-400 hover:bg-gray-50'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              {previewUrl ? (
                <div className="space-y-6">
                  <div className="relative inline-block">
                    <img
                      src={previewUrl}
                      alt="Selected rice"
                      className="max-w-md max-h-64 object-contain rounded-xl shadow-lg"
                    />
                    <button
                      onClick={() => {
                        setSelectedFile(null);
                        setPreviewUrl(null);
                      }}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-red-600 transition-colors"
                    >
                      ×
                    </button>
                  </div>
                  <p className="text-gray-600 font-medium">{selectedFile?.name}</p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center mx-auto">
                    <Upload className="h-8 w-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-semibold text-gray-900 mb-2">
                      Upload Rice Image
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Drag and drop your image here, or click to browse
                    </p>
                    <p className="text-sm text-gray-500">
                      Supported formats: JPG, PNG, GIF (Max 10MB)
                    </p>
                  </div>
                </div>
              )}

              <input
                type="file"
                onChange={handleFileChange}
                accept="image/*"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>

            {/* Info Section */}
            <div className="mt-8 p-6 bg-amber-50 rounded-xl border border-amber-200">
              <div className="flex items-start space-x-3">
                <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-amber-800">
                  <p className="font-semibold mb-2">Tips for Best Results:</p>
                  <ul className="space-y-1 list-disc list-inside">
                    <li>Use clear, well-lit images of rice grains</li>
                    <li>Ensure grains are clearly visible and not blurry</li>
                    <li>Avoid extreme close-ups or distant shots</li>
                    <li>Include multiple grains in the image for better accuracy</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              <button
                onClick={handleSubmit}
                disabled={!selectedFile || isUploading}
                className={`flex-1 flex items-center justify-center space-x-2 py-4 px-6 rounded-xl font-semibold transition-all duration-300 ${
                  selectedFile && !isUploading
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-lg hover:shadow-xl hover:scale-105'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                {isUploading ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    <span>Analyzing...</span>
                  </>
                ) : (
                  <>
                    <Camera className="h-5 w-5" />
                    <span>Classify Rice Type</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Rice Types Info */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { name: 'Basmati', description: 'Long-grain aromatic rice popular in Indian cuisine' },
            { name: 'Jasmine', description: 'Fragrant long-grain rice commonly used in Thai cooking' },
            { name: 'Arborio', description: 'Short-grain rice perfect for creamy risotto dishes' },
            { name: 'Brown Rice', description: 'Whole grain rice with higher fiber and nutrients' },
            { name: 'Wild Rice', description: 'Native grain with nutty flavor and chewy texture' },
          ].map((rice, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{rice.name}</h3>
              <p className="text-gray-600 text-sm">{rice.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PredictPage;