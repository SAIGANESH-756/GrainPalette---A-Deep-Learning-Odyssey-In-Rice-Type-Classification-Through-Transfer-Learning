import React from 'react';
import { Link } from 'react-router-dom';
import { Camera, Users, Lightbulb, TrendingUp, ArrowRight, Wheat, Droplets, Sun } from 'lucide-react';

const HomePage: React.FC = () => {
  const features = [
    {
      icon: Camera,
      title: 'Instant Classification',
      description: 'Upload rice grain images and get instant AI-powered classification results with confidence scores.'
    },
    {
      icon: TrendingUp,
      title: 'High Accuracy',
      description: 'Built with MobileNetV4 transfer learning technology achieving 95%+ accuracy on rice variety identification.'
    },
    {
      icon: Users,
      title: 'For Everyone',
      description: 'Perfect for farmers, researchers, agriculture scientists, and gardening enthusiasts worldwide.'
    },
    {
      icon: Lightbulb,
      title: 'Smart Insights',
      description: 'Get detailed information about rice varieties including cultivation tips and characteristics.'
    }
  ];

  const scenarios = [
    {
      icon: Wheat,
      title: 'Farmers\' Crop Planning',
      description: 'Identify rice varieties in your seed stock to optimize cultivation strategies, irrigation, and fertilization.'
    },
    {
      icon: Sun,
      title: 'Research & Extension',
      description: 'Support agricultural research and extension services with rapid variety identification during field visits.'
    },
    {
      icon: Droplets,
      title: 'Home Gardening',
      description: 'Learn about different rice varieties and enhance your gardening knowledge with AI-powered identification.'
    }
  ];

  return (
    <main className="flex-1">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="max-w-7xl mx-auto text-center relative">
          <div className="absolute inset-0 bg-gradient-to-r from-amber-400/10 via-green-400/10 to-amber-400/10 rounded-full blur-3xl"></div>
          
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-amber-600 via-green-600 to-amber-600 bg-clip-text text-transparent">
              GrainPalette
            </span>
            <br />
            <span className="text-gray-800 text-3xl md:text-4xl">
              AI Rice Classification
            </span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
            Harness the power of deep learning to identify rice varieties instantly. 
            Perfect for farmers, researchers, and agriculture enthusiasts seeking 
            accurate grain classification.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link
              to="/predict"
              className="group bg-gradient-to-r from-amber-500 to-amber-600 text-white px-8 py-4 rounded-2xl font-semibold shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 flex items-center space-x-2"
            >
              <Camera className="h-5 w-5" />
              <span>Start Classification</span>
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Link>
            
            <Link
              to="/about"
              className="px-8 py-4 border-2 border-gray-300 text-gray-700 rounded-2xl font-semibold hover:border-amber-300 hover:bg-amber-50 transition-all duration-300 flex items-center space-x-2"
            >
              <span>Learn More</span>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose GrainPalette?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Advanced AI technology meets agricultural expertise to deliver 
              accurate and reliable rice variety identification.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="group bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-gray-100">
                <div className="w-14 h-14 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="h-7 w-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Real-World Applications
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover how GrainPalette transforms rice identification across 
              different agricultural scenarios and use cases.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {scenarios.map((scenario, index) => (
              <div key={index} className="bg-gradient-to-br from-white to-amber-50 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-amber-100">
                <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center mb-6">
                  <scenario.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">{scenario.title}</h3>
                <p className="text-gray-600 leading-relaxed">{scenario.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-amber-500 to-green-500">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Identify Your Rice Varieties?
          </h2>
          <p className="text-xl text-amber-100 mb-8 max-w-2xl mx-auto">
            Join thousands of farmers and researchers who trust GrainPalette 
            for accurate rice variety identification.
          </p>
          <Link
            to="/predict"
            className="inline-flex items-center space-x-2 bg-white text-amber-600 px-8 py-4 rounded-2xl font-semibold shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
          >
            <Camera className="h-5 w-5" />
            <span>Start Classifying Now</span>
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </main>
  );
};

export default HomePage;