import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Camera, ArrowLeft, BarChart3, Info, Lightbulb } from 'lucide-react';

interface ResultsPageProps {
  result: {
    predicted_class: string;
    confidence: number;
    all_predictions: { [key: string]: number };
  } | null;
  uploadedImage: string | null;
}

const ResultsPage: React.FC<ResultsPageProps> = ({ result, uploadedImage }) => {
  if (!result) {
    return (
      <div className="flex-1 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">No Results Available</h1>
          <p className="text-gray-600 mb-8">Please upload an image first to see classification results.</p>
          <Link
            to="/predict"
            className="inline-flex items-center space-x-2 bg-amber-500 text-white px-6 py-3 rounded-xl font-semibold hover:bg-amber-600 transition-colors"
          >
            <Camera className="h-5 w-5" />
            <span>Upload Image</span>
          </Link>
        </div>
      </div>
    );
  }

  const riceInfo = {
    'Basmati': {
      description: 'Basmati is a long-grain aromatic rice variety known for its distinctive fragrance and delicate flavor.',
      characteristics: ['Long, slender grains', 'Aromatic fragrance', 'Fluffy texture when cooked', 'Low glycemic index'],
      cultivation: 'Requires well-drained soil and specific climate conditions. Best grown in the foothills of the Himalayas.',
      uses: 'Perfect for biryanis, pilafs, and Indian cuisine. Pairs well with curries and spiced dishes.'
    },
    'Jasmine': {
      description: 'Jasmine rice is a long-grain variety of fragrant rice with a subtle floral aroma and slightly sticky texture.',
      characteristics: ['Fragrant aroma', 'Slightly sticky texture', 'Translucent grains', 'Sweet flavor'],
      cultivation: 'Thrives in tropical climates with abundant water. Primarily grown in Thailand and Southeast Asia.',
      uses: 'Staple in Thai cuisine, excellent with stir-fries, curries, and as a side dish for Asian meals.'
    },
    'Arborio': {
      description: 'Arborio is a short-grain rice variety known for its high starch content, perfect for creamy dishes.',
      characteristics: ['Short, rounded grains', 'High starch content', 'Creamy texture', 'Absorbs flavors well'],
      cultivation: 'Grown primarily in the Po Valley of Italy. Requires specific irrigation and climate conditions.',
      uses: 'Essential for risotto, rice pudding, and other creamy rice dishes. Absorbs broth and flavors beautifully.'
    },
    'Brown Rice': {
      description: 'Brown rice is whole grain rice with the bran layer intact, offering higher nutritional value.',
      characteristics: ['Nutty flavor', 'Chewy texture', 'Higher fiber content', 'Rich in nutrients'],
      cultivation: 'Can be grown in various climates. Simply unprocessed white rice with bran layer preserved.',
      uses: 'Healthy alternative to white rice, great for salads, bowls, and health-conscious cooking.'
    },
    'Wild Rice': {
      description: 'Wild rice is actually a grass seed with a nutty flavor and chewy texture, native to North America.',
      characteristics: ['Dark color', 'Nutty flavor', 'Chewy texture', 'High protein content'],
      cultivation: 'Grows naturally in shallow freshwater marshes and along lakeshores in North America.',
      uses: 'Excellent in salads, stuffings, soups, and as a nutritious side dish or grain bowl base.'
    }
  };

  const currentRiceInfo = riceInfo[result.predicted_class as keyof typeof riceInfo];
  const confidencePercentage = Math.round(result.confidence * 100);
  const sortedPredictions = Object.entries(result.all_predictions)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 5);

  return (
    <div className="flex-1 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mx-auto mb-4">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Classification Complete!</h1>
          <p className="text-xl text-gray-600">Here are your rice identification results</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Image and Main Result */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="p-6">
              {uploadedImage && (
                <div className="mb-6">
                  <img
                    src={uploadedImage}
                    alt="Uploaded rice"
                    className="w-full h-64 object-contain rounded-xl bg-gray-50"
                  />
                </div>
              )}
              
              <div className="text-center">
                <h2 className="text-3xl font-bold text-gray-900 mb-2">
                  {result.predicted_class}
                </h2>
                <div className="flex items-center justify-center space-x-2 mb-4">
                  <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                  <span className="text-xl font-semibold text-green-600">
                    {confidencePercentage}% Confidence
                  </span>
                </div>
                
                {/* Confidence Bar */}
                <div className="w-full bg-gray-200 rounded-full h-3 mb-6">
                  <div 
                    className="bg-gradient-to-r from-green-400 to-green-600 h-3 rounded-full transition-all duration-1000 ease-out"
                    style={{ width: `${confidencePercentage}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>

          {/* All Predictions */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="p-6">
              <div className="flex items-center space-x-2 mb-6">
                <BarChart3 className="h-6 w-6 text-amber-600" />
                <h3 className="text-2xl font-bold text-gray-900">All Predictions</h3>
              </div>
              
              <div className="space-y-4">
                {sortedPredictions.map(([riceName, confidence], index) => (
                  <div key={riceName} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className={`font-medium ${index === 0 ? 'text-green-600' : 'text-gray-700'}`}>
                        {riceName}
                      </span>
                      <span className={`font-semibold ${index === 0 ? 'text-green-600' : 'text-gray-600'}`}>
                        {Math.round(confidence * 100)}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full transition-all duration-1000 ease-out ${
                          index === 0 
                            ? 'bg-gradient-to-r from-green-400 to-green-600' 
                            : 'bg-gradient-to-r from-gray-300 to-gray-400'
                        }`}
                        style={{ width: `${confidence * 100}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Rice Information */}
        {currentRiceInfo && (
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden mb-8">
            <div className="p-8">
              <div className="flex items-center space-x-2 mb-6">
                <Info className="h-6 w-6 text-amber-600" />
                <h3 className="text-2xl font-bold text-gray-900">About {result.predicted_class} Rice</h3>
              </div>
              
              <p className="text-gray-700 text-lg leading-relaxed mb-8">
                {currentRiceInfo.description}
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-amber-50 rounded-xl p-6 border border-amber-200">
                  <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                    <div className="w-2 h-2 bg-amber-500 rounded-full mr-2"></div>
                    Characteristics
                  </h4>
                  <ul className="space-y-2">
                    {currentRiceInfo.characteristics.map((char, index) => (
                      <li key={index} className="text-sm text-gray-700 flex items-start">
                        <span className="w-1.5 h-1.5 bg-amber-400 rounded-full mr-2 mt-2 flex-shrink-0"></span>
                        {char}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="bg-green-50 rounded-xl p-6 border border-green-200">
                  <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    Cultivation
                  </h4>
                  <p className="text-sm text-gray-700 leading-relaxed">
                    {currentRiceInfo.cultivation}
                  </p>
                </div>
                
                <div className="bg-blue-50 rounded-xl p-6 border border-blue-200">
                  <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                    Culinary Uses
                  </h4>
                  <p className="text-sm text-gray-700 leading-relaxed">
                    {currentRiceInfo.uses}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/predict"
            className="flex items-center justify-center space-x-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white px-8 py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
          >
            <Camera className="h-5 w-5" />
            <span>Classify Another Image</span>
          </Link>
          
          <Link
            to="/"
            className="flex items-center justify-center space-x-2 border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-xl font-semibold hover:border-amber-300 hover:bg-amber-50 transition-all duration-300"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Home</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;