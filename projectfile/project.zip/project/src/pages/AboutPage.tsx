import React from 'react';
import { Brain, Target, Users, Cpu, Database, Award } from 'lucide-react';

const AboutPage: React.FC = () => {
  const features = [
    {
      icon: Brain,
      title: 'Deep Learning Technology',
      description: 'Powered by advanced Convolutional Neural Networks (CNN) with MobileNetV4 architecture for optimal performance and accuracy.'
    },
    {
      icon: Target,
      title: '95%+ Accuracy',
      description: 'Our transfer learning approach achieves industry-leading accuracy rates in rice variety classification across diverse grain types.'
    },
    {
      icon: Cpu,
      title: 'Real-time Processing',
      description: 'Fast inference times ensure you get classification results within seconds of uploading your rice grain images.'
    },
    {
      icon: Database,
      title: 'Comprehensive Dataset',
      description: 'Trained on thousands of rice grain images across multiple varieties for robust and reliable identification.'
    }
  ];

  const team = [
    {
      role: 'AI/ML Engineers',
      description: 'Specialized in computer vision and deep learning, bringing expertise in neural network architectures and model optimization.'
    },
    {
      role: 'Agricultural Scientists',
      description: 'Domain experts who ensure our classifications align with real-world agricultural knowledge and standards.'
    },
    {
      role: 'Software Developers',
      description: 'Full-stack developers creating intuitive interfaces and robust backend systems for seamless user experiences.'
    }
  ];

  return (
    <div className="flex-1 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            About <span className="bg-gradient-to-r from-amber-600 to-green-600 bg-clip-text text-transparent">GrainPalette</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            GrainPalette represents the cutting edge of agricultural AI, combining deep learning 
            technology with agricultural expertise to deliver accurate rice variety identification 
            for farmers, researchers, and agriculture enthusiasts worldwide.
          </p>
        </div>

        {/* Mission Section */}
        <div className="bg-gradient-to-r from-amber-500 to-green-500 rounded-2xl p-12 mb-16 text-center text-white">
          <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
          <p className="text-xl leading-relaxed max-w-4xl mx-auto">
            To democratize agricultural technology by making advanced rice variety identification 
            accessible to everyone, from smallholder farmers in rural areas to large-scale 
            agricultural operations, fostering better crop management and food security globally.
          </p>
        </div>

        {/* Technology Section */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Powered by Advanced AI
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our classification system leverages state-of-the-art deep learning 
              techniques to provide reliable and accurate rice variety identification.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 border border-gray-100">
                <div className="w-14 h-14 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center mb-6">
                  <feature.icon className="h-7 w-7 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Technical Details */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-16 border border-gray-100">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Technical Architecture</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <div className="w-3 h-3 bg-amber-500 rounded-full mr-3"></div>
                Model Architecture
              </h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                  MobileNetV4 as feature extractor with transfer learning
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                  Custom dense layers for rice-specific classification
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                  Optimized for mobile and web deployment
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                  Real-time inference capabilities
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                Data Processing
              </h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-amber-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                  Image preprocessing and augmentation
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-amber-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                  Standardized input dimensions (224x224x3)
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-amber-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                  Robust handling of various image formats
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-amber-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                  Quality validation and error handling
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Team Section */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Expert Team
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our multidisciplinary team combines expertise in AI, agriculture, 
              and software development to create reliable solutions.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-gradient-to-br from-white to-amber-50 rounded-2xl p-8 shadow-lg border border-amber-100">
                <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center mb-6">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{member.role}</h3>
                <p className="text-gray-600 leading-relaxed">{member.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Impact Section */}
        <div className="bg-gray-50 rounded-2xl p-12 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Award className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Making a Global Impact</h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            GrainPalette is already helping farmers, researchers, and agriculture enthusiasts 
            worldwide make informed decisions about rice cultivation, contributing to better 
            crop yields, sustainable farming practices, and global food security.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;