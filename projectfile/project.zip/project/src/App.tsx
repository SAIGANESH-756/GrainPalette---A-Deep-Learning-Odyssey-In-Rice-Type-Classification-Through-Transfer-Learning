import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import PredictPage from './pages/PredictPage';
import ResultsPage from './pages/ResultsPage';
import AboutPage from './pages/AboutPage';

interface PredictionResult {
  predicted_class: string;
  confidence: number;
  all_predictions: { [key: string]: number };
}

function App() {
  const [predictionResult, setPredictionResult] = useState<PredictionResult | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-green-50">
        <Header />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route 
            path="/predict" 
            element={
              <PredictPage 
                setPredictionResult={setPredictionResult}
                setUploadedImage={setUploadedImage}
              />
            } 
          />
          <Route 
            path="/results" 
            element={
              <ResultsPage 
                result={predictionResult}
                uploadedImage={uploadedImage}
              />
            } 
          />
          <Route path="/about" element={<AboutPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;